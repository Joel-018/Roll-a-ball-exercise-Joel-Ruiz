using UnityEngine;
using UnityEngine.AI;
using System.Collections;

public class EnemyMovement : MonoBehaviour
{
    public Transform player;
    private NavMeshAgent navMeshAgent;
    private bool isParalyzed = false;

    void Start() {
        navMeshAgent = GetComponent<NavMeshAgent>();
    }

    void Update() {
        if (isParalyzed || player == null) return;

        if (navMeshAgent != null && navMeshAgent.enabled) {    
            navMeshAgent.SetDestination(player.position);
        }
    }

    public void Paralyze(float duration) {
        if (!isParalyzed) StartCoroutine(ParalyzeRoutine(duration));
    }

    IEnumerator ParalyzeRoutine(float duration) {
        isParalyzed = true;
        if (navMeshAgent != null) {
            navMeshAgent.isStopped = true; 
            navMeshAgent.velocity = Vector3.zero;
        }

        // Buscamos el Renderer en este objeto o en sus hijos para evitar el error
        Renderer rendererComp = GetComponentInChildren<Renderer>();
        Color originalColor = Color.red;

        if (rendererComp != null) {
            originalColor = rendererComp.material.color;
            rendererComp.material.color = Color.blue; 
        }

        yield return new WaitForSeconds(duration);

        // Volver a la normalidad
        if (rendererComp != null) rendererComp.material.color = originalColor;
        if (navMeshAgent != null) navMeshAgent.isStopped = false;
        isParalyzed = false;
    }
}