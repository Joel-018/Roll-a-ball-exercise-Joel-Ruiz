using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;
using System.Collections;

public class PlayerController : MonoBehaviour
{
    private Rigidbody rb; 
    private int count;
    private float movementX;
    private float movementY;

    public float speed = 10;
    public TextMeshProUGUI countText;
    public GameObject winTextObject;
    public GameObject paralysisTextObject; // Arrastra aquí el nuevo texto de aviso

    void Start() {
        rb = GetComponent<Rigidbody>();
        count = 0;
        SetCountText();
        winTextObject.SetActive(false);
        if (paralysisTextObject != null) paralysisTextObject.SetActive(false);
    }
 
    void OnMove(InputValue movementValue) {
        Vector2 movementVector = movementValue.Get<Vector2>();
        movementX = movementVector.x; 
        movementY = movementVector.y; 
    }

    void FixedUpdate() {
        Vector3 movement = new Vector3(movementX, 0.0f, movementY);
        rb.AddForce(movement * speed); 
    }

    void OnTriggerEnter(Collider other) {
        if (other.gameObject.CompareTag("PickUp")) {
            other.gameObject.SetActive(false);
            count++;
            SetCountText();

            if (count % 4 == 0) {
                GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
                foreach (GameObject e in enemies) {
                    EnemyMovement enemyScript = e.GetComponent<EnemyMovement>();
                    if (enemyScript != null) enemyScript.Paralyze(5f);
                }
                // Activa el texto de aviso
                if (paralysisTextObject != null) StartCoroutine(ShowParalysisMessage());
            }
        }
    }

    IEnumerator ShowParalysisMessage() {
        paralysisTextObject.SetActive(true);
        yield return new WaitForSeconds(5f);
        paralysisTextObject.SetActive(false);
    }

    void SetCountText() {
        countText.text = "Count: " + count.ToString();
        if (count >= 10) {
            winTextObject.SetActive(true);
            foreach(GameObject e in GameObject.FindGameObjectsWithTag("Enemy")) Destroy(e);
        }
    }

    private void OnCollisionEnter(Collision collision) {
        if (collision.gameObject.CompareTag("Enemy")) {
            Destroy(gameObject); 
            winTextObject.SetActive(true);
            winTextObject.GetComponent<TextMeshProUGUI>().text = "You Lose!";
        }
    }
}